# Third-party asset credits

- Lowpoly Racetrack - cc-by-4.0, credit FSkala - Source: https://sketchfab.com/3d-models/lowpoly-racetrack-a2bd81e85612454c8f978f38f1aae0f2
- Asset of low-poly cars — car 04 - cc-by-4.0, credit Qualix_studio - Source: https://sketchfab.com/3d-models/asset-of-low-poly-cars-9ecf9b46cd5f4ce483feed56116599f2
- Asset of low-poly cars — car 02 - cc-by-4.0, credit Qualix_studio - Source: https://sketchfab.com/3d-models/asset-of-low-poly-cars-9ecf9b46cd5f4ce483feed56116599f2
- Asset of low-poly cars — car 09 - cc-by-4.0, credit Qualix_studio - Source: https://sketchfab.com/3d-models/asset-of-low-poly-cars-9ecf9b46cd5f4ce483feed56116599f2
- race track assets pack conus clear - cc-by-4.0, credit Cherk - Source: https://sketchfab.com/3d-models/race-track-assets-pack-4a863e7005d647adb2f72775cf41e808
